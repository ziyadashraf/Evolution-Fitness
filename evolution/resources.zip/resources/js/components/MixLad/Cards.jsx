import Card from "./Card"
import { Link } from "react-router-dom"

const Cards = (props) => {
    return (

        <Card type={props.type} />



    )
}

export default Cards