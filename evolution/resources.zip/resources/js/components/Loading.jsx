import React from 'react';
import "../../css/app.css";



import { useEffect } from "react";





function Loading() {

    useEffect(() => {
        window.scrollTo(0, 0)


    });

    return (
        <div id="app">
            hi
        </ div>
    )

}

export default Loading